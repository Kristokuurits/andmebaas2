﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseTask.Core.Domain
{
    public class Patient_Stay
    {
        [Key]
        public Guid Id { get; set; }
        public Guid Patient_ID { get; set; }
        public string AdmissionDate { get; set; }
        public string DischargeDate { get; set; }
        public Guid Room_ID { get; set; }
        public IEnumerable<Patient> Patient { get; set; } = new List<Patient>();
    }
}