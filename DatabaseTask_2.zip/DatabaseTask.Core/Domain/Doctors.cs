﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseTask.Core.Domain
{
    public class Doctors
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Department_ID { get; set; }
        public IEnumerable<Departments> Department { get; set; } = new List<Departments>();
    }
}